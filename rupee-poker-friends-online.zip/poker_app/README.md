# Rupee Poker Friends

A private, play-money multiplayer poker app for friends. It supports Texas Hold'em, Omaha, Teen Patti and High Card, with real-time rooms/chat over Socket.IO.

## Local

```bash
npm install
npm start
```

Open `http://localhost:3000`.

## Deploy online with Render

This project includes `render.yaml` and is ready to deploy as a Node web service. Render supports Node/Express web services and inbound WebSockets, which Socket.IO uses for real-time multiplayer. See the official Render docs:

- https://render.com/docs/deploy-node-express-app
- https://render.com/docs/websocket

### GitHub + Render

1. Create a GitHub repository and upload the contents of this folder (including `render.yaml`).
2. In Render, choose **New → Web Service** and connect the GitHub repository.
3. Render will use `npm install` and `npm start` from `render.yaml`.
4. Deploy and open the generated `onrender.com` URL.
5. Share that URL with your friends. They can create/join tables from phones or computers.

Render web services receive a public `onrender.com` URL and support inbound WebSocket connections. For public WebSocket connections, the browser should use the secure `wss` connection; Socket.IO handles this automatically when the page is served over HTTPS.

## Important multiplayer note

The current version keeps active rooms in server memory. It is suitable for a small private friend group on a single server instance. Do not enable horizontal/multi-instance scaling without adding a shared Socket.IO adapter and shared room/game state (for example Redis/Postgres), otherwise players can land on different instances.

## Play-money only

Balances are fictional. The app does not process deposits, withdrawals, cash prizes, or real-money wagers.
